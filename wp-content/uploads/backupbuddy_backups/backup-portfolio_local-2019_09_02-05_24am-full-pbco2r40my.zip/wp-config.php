<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '0FAaUKumQ4n2cVLP/cHzdgCR5sS9NB8DC/tRK+gY3JiqyEuoPXZh3WeyF+h3T3vNIrEE/1xahDr7RpnESlopzw==');
define('SECURE_AUTH_KEY',  '3rupiijkkU6XyXkw79ayWgSl4uUVKbxqS+yQGH8WhyXPs838WtrIEc1l6HDQypBHLX0Uk5/ME6Vw7pTAjArZBw==');
define('LOGGED_IN_KEY',    'usxEIPjZGrIWk00Ul9A1uDIpcABqevoPSNj7NROY3xagxPgL0F+n1f/biPhuxCiVr0SL5Q+S/Lg9Ujqe/8lBZQ==');
define('NONCE_KEY',        '7vEyQTp3oK3iwdTRtAC3bh0Nn2KuZpviaUZdsI6awcwbrNGSF8QYZ5vDRuRrvfTkPJQ5VtUeWcDPBERkTKEljQ==');
define('AUTH_SALT',        'y4+d8rCGVB9aBOWYSA7IotdQaUYGTHVTtJa5U1VmginYjUkBTVTJ3T+TR/KRt0KvCrN3PgXDK/e9SGcAHCGM4A==');
define('SECURE_AUTH_SALT', 'iSWMDE/ZUh3WnyjEFlZApAJpd2iCrX9M5Z+qf7mpVgkSiBUGO6Dpryvx7+5dAGKEZC6BUlwVhAZgSr1bfWp8xw==');
define('LOGGED_IN_SALT',   '3YMn9/wuKDWlcRBquadVY/zAI+TOaJu9jT/a84Ooelrf1WrthSYT+nwXDhbDKPDejPVKPZQnJEFZtTXZFGjc7g==');
define('NONCE_SALT',       'X8lVQTVINFuWTLqfn5iH/OB+RxEOUU0RbGKMqbbzQ2W7X4s+rb6t1gX3CmIWNsJGxZNiSqSePLf+B/bEmFK8ew==');

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) )
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
